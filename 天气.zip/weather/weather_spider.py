"""
如果需要Python开发工具和案例代码，可以一键三联后私信领取。
"""

import csv  # 写入csv文件
import requests  # 模拟浏览器进行网络请求
from lxml import etree  # 进行数据预处理


def get_weather(url):
    weather_info = []  # 新建一个列表,将爬取的每月数据放进去
    # 请求头信息:浏览器版本型号,接收数据的编码格式
    headers = {
        # 必填,不填拿不到数据
        'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/535.1 (KHTML, like Gecko) Chrome/14.0.835.163 Safari/535.1'
    }
    # 请求
    resp = requests.get(url, headers=headers)
    # 数据预处理
    resp_html = etree.HTML(resp.text)
    # xpath提取所有数据
    resp_list = resp_html.xpath("//ul[@class='thrui']/li")

    # for循环迭代遍历
    for li in resp_list:
        # 定义每天的天气数据字典
        day_weather_info = {
            # 获取日期，格式为 2023-01-01
            'date_time': li.xpath("./div[1]/text()")[0].split(' ')[0],
            # 获取最高气温，并去除摄氏度符号
            'high': li.xpath("./div[2]/text()")[0].replace('℃', ''),
            # 获取最低气温，并去除摄氏度符号
            'low': li.xpath("./div[3]/text()")[0].replace('℃', ''),
            # 获取天气文本信息
            'weather':  li.xpath("./div[4]/text()")[0]
        }

        # 再将每天的数据字典放入每月数据列表中
        weather_info.append(day_weather_info)

    # 返回每个月的天气数据列表
    return weather_info


# 全年的天气数据列表 大概长这样子 :[ [ {},{},.. ],[{},{},..],[{},{},..], ]
# 外层列表:年数据,里层列表:月数据,里层列表中的每个字典:这个月中每天的气候数据
weathers = []

# for循环生成有顺序的1-12
for month in range(1, 13):
    # 找url规律  进行拼接 -- 拿的是某一月里的所有数据
    # 获取对应月份的天气信息
    weather_time = f'2023{month:02}'
    url = f'https://lishi.tianqi.com/changsha/{weather_time}.html'

    # 爬虫获取这个月的天气信息
    weather = get_weather(url)
    # print(weather)

    # 存到列表中
    weathers.append(weather)

print(weathers)

# 数据写入(一次性写入)
with open("weather.csv", "w", newline='') as csvfile:
    writer = csv.writer(csvfile)

    # 先写入列名:columns_name
    writer.writerow(["日期", "最高气温", "最低气温", '天气'])

    # 遍历出每个月的天气信息
    for month_weather in weathers:
        # 遍历出每天的天气信息
        for day_weather_dict in month_weather:
            # 将每天的天气信息写入csv文件
            writer.writerow(list(day_weather_dict.values()))
