"""
如果需要Python开发工具和案例代码，可以一键三联后私信领取。
"""

import pandas as pd
from pyecharts import options as opts
from pyecharts.charts import Bar, Timeline


# 用pandas.read_csv()读取指定的excel文件,选择编码格式gb18030(gb18030范围比)
df = pd.read_csv('weather.csv', encoding='gb18030')
# print(df['日期'])

# 使用 pandas.apply() 函数自动遍历DataFrame对象, 然后使用lambda表达式逐个将字符串转换成时间类型
# 这里必须要转换，否则日期不是datetime类型,就无法做该类型的相关操作。
df['日期'] = df['日期'].apply(lambda x: pd.to_datetime(x))
# print(df['日期'])

"""
0     2019-01-01
1     2019-01-02
2     2019-01-03
3     2019-01-04
4     2019-01-05
         ...    
359   2019-12-26
360   2019-12-27
361   2019-12-28
362   2019-12-29
363   2019-12-30
"""

# 新建一列月份数据(将日期中的月份一项单独拿取出来)
df['month'] = df['日期'].dt.month
# print(df['month'])

# 需要的数据 每个月中每种天气出现的次数
"""
month(月份)   tianqi(天气)   count(出现次数)
1                  晴         8
1                  雨         9
1                  多云        4
1                  阵雨        10 
...
"""

# 使用reset_index()重置索引，如果不重置索引就会默认把month列做为索引列，但month列已经不是连续的索引了
df_agg = df.groupby(['month', '天气']).size().reset_index()
# print(df_agg)
"""
'重置前':
month  天气 
1      多云      5
       晴       2
       阴      20
       雨夹雪     4
2      多云      3
       阴      21
       雨夹雪     4
3      多云      6
       晴       1
       阴      24
4      多云      6
       晴       2
       阴      22
5      多云      9
       晴       2
       阴      20
6      多云      5
       小雨      2
       晴       2
       阴      20
       阵雨      1
7      多云     11
       大雨      1
       晴       6
       阴      13
8      多云      8
       晴      10
       阴      13
9      多云     12
       晴      14
       阴       4
10     中雨      1
       多云      7
       小雨      9
       晴       7
       阴       7
11     中雨      1
       多云     11
       小雨      6
       晴       4
       阴       7
       阵雨      1
12     多云      6
       小雨      8
       晴       7
       阴       7
       雾       2

'重置后':
    month   天气   0(还没设置列名,所以是0)
0       1   多云   5
1       1    晴   2
2       1    阴  20
3       1  雨夹雪   4
4       2   多云   3
5       2    阴  21
6       2  雨夹雪   4
7       3   多云   6
8       3    晴   1
9       3    阴  24
10      4   多云   6
11      4    晴   2
12      4    阴  22
13      5   多云   9
14      5    晴   2
15      5    阴  20
16      6   多云   5
17      6   小雨   2
18      6    晴   2
19      6    阴  20
20      6   阵雨   1
21      7   多云  11
22      7   大雨   1
23      7    晴   6
24      7    阴  13
25      8   多云   8
26      8    晴  10
27      8    阴  13
28      9   多云  12
29      9    晴  14
30      9    阴   4
31     10   中雨   1
32     10   多云   7
33     10   小雨   9
34     10    晴   7
35     10    阴   7
36     11   中雨   1
37     11   多云  11
38     11   小雨   6
39     11    晴   4
40     11    阴   7
41     11   阵雨   1
42     12   多云   6
43     12   小雨   8
44     12    晴   7
45     12    阴   7
46     12    雾   2
"""

# 设置下这3列的列名
df_agg.columns = ['month', 'tianqi', 'count']
print(df_agg)

# 天气数据的形成
# 选择一月的所有数据(bool值取数据),将里面的'tianqi','count'2列数据拿出来排序
# 排序又是怎么排呢? 以'count'列为依据,逆序(从大到小排列),因为目前取出来是DataFrame的数据类型
# .value:拿出来的数据是一个numpy.ndarray数组,再用.tolist()转化为列表数据
# print(df_agg[df_agg['month'] == 1][['tianqi', 'count']].sort_values(by='count', ascending=False).values.tolist())
"""
[['阴', 20], ['多云', 5], ['雨夹雪', 4], ['晴', 2]]
"""

# 画图
# 实例化一个时间序列的对象
timeline = Timeline()
# 播放参数:设置时间间隔 1s  单位是:ms(毫秒)
timeline.add_schema(play_interval=1000)  # 单位是:ms(毫秒)

# 循环遍历df_agg['month']里的唯一值
for month in df_agg['month'].unique():
    # 获取天气的值
    data = (
        df_agg[df_agg['month'] == month][['tianqi', 'count']]
        .sort_values(by='count', ascending=True)
        .values.tolist()
    )
    # print(data)

    # 绘制柱状图
    bar = Bar()
    # x轴是天气名称
    bar.add_xaxis([x[0] for x in data])
    # y轴是出现次数
    bar.add_yaxis('', [x[1] for x in data])

    # 让柱状图横着放
    bar.reversal_axis()
    # 将计数标签放置在图形右边
    bar.set_series_opts(label_opts=opts.LabelOpts(position='right'))
    # 设置下图表的名称
    bar.set_global_opts(title_opts=opts.TitleOpts(title='长沙2023年每月天气变化 '))
    # 将设置好的bar对象放置到时间轮播图当中,并且标签选择月份 格式为: 数字月
    timeline.add(bar, f'{month}月')

# 将设置好的图表保存为weathers.html文件
timeline.render('weathers.html')
