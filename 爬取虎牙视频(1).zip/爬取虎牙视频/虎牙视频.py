import requests
import re
import os

filename = '视频\\'
if not os.path.exists(filename):
    os.mkdir(filename)

for page in range(1, 501):
    if page == 1:
        link = 'https://v.huya.com/g/all?set_id=51'
    else:
        link = f'https://v.huya.com/g/all?set_id=51&order=hot&page={page}'

    headers = {
        # 浏览器的身份标识
        'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/109.0.0.0 Safari/537.36'
    }
    html_data = requests.get(url=link, headers=headers).text

    info = re.findall('<a href="//v.huya.com/play/(.*?).html" class=', html_data)
    for rid in info:
        url = f'https://liveapi.huya.com/moment/getMomentContent?&videoId={rid}'


        response = requests.get(url=url, headers=headers)
        json_data = response.json()
        title = json_data['data']['moment']['title']
        play_url = json_data['data']['moment']['videoInfo']['definitions'][0]['url']

        video_content = requests.get(url=play_url, headers=headers).content
        with open(filename + title + '.mp4', mode='wb') as f:
            f.write(video_content)
            print('正在下载视频 ', title)
