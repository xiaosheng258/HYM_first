# 文本转语音
# 公众号： 优特编程
# 网站： https://www.xuepy.com


import pyttsx3


engine = pyttsx3.init()

# engine.say("Beautiful is better than ugly.")
# engine.say("轻轻地，我走了，正如我轻轻地来……")
engine.say("小说《边城》，作者：沈从文")

with open('text.txt', 'r', encoding='utf8') as f:
    engine.say(f.read())

engine.runAndWait()
